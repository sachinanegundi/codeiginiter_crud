create database "crud"

create table "student"

CREATE TABLE student (
    id int PRIMARY KEY AUTO_INCREMENT,
    studentname varchar(50),
    usn varchar(50),
    branch varchar(50),
    collegename varchar(50),
    address varchar(50),
);