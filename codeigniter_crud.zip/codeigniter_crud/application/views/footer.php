<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
	<div class="container-fluid">
		<div class="navbar-header">
			<a class="navbar-brand" href="#"> CRUD Application</a>
		</div>	
	</div>
</nav>

<script type="text/js" src="<?php echo base_url("assets/css/js.css"); ?>"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>