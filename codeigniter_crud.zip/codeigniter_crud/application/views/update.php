<?php include('header.php');?>
<br>
<main>
<div class="container bg">
    <div class="row justify-content-center">
      <div class="col-12  col-sm-5">
        <?php echo form_open("home/update/{$record->id}", ['class'=>'form-container']); ?>
          <div class="form-group">
            <label for="exampleInputEmail1">Student Name</label>
            <?php echo form_input(['name'=>'studentname','class'=>'form-control','placeholder'=>'Enter StudentName','value'=>set_value('studentname',$record->studentname)]); ?>
            <?php echo form_error('studentname'); ?>
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Usn</label>
            <?php echo form_input(['name'=>'usn','class'=>'form-control','placeholder'=>'Enter USN','value'=>set_value('usn',$record->usn)]); ?>
            <?php echo form_error('usn'); ?>
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Branch</label>
            <?php echo form_input(['name'=>'branch','class'=>'form-control','placeholder'=>'Enter branch','value'=>set_value('branch',$record->branch)]); ?>
            <?php echo form_error('branch'); ?>
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">College Name</label>
            <?php echo form_input(['name'=>'collegename','class'=>'form-control','placeholder'=>'Enter collegename','value'=>set_value('collegename',$record->collegename)]); ?>
            <?php echo form_error('collegename'); ?>
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Address</label>
            <?php echo form_input(['name'=>'address','class'=>'form-control','placeholder'=>'Enter address','value'=>set_value('address',$record->address)]); ?>
            <?php echo form_error('address'); ?>
          </div>
          <?php echo form_submit(['value'=>'Reset','class'=>'btn btn-default']); ?>
          <?php echo form_submit(['value'=>'submit','class'=>'btn btn-primary']); ?>
        </form>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>
  </main>

<?php include('footer.php');?>