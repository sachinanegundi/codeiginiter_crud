<?php

    class Crudmodel extends CI_Model{

        public function getRecords() {
            $query = $this->db->get('student');
            if( $query->num_rows() > 0) {
                return $query->result();
            }
        }

        public function saveRecord($data) {
            return $this->db->insert('student', $data);
        }

        public function getAllRecords( $record_id ) {

            $query = $this->db->get_where('student', array('id' => $record_id));
            if( $query ->num_rows() > 0 ) {
                return $query->row();
            }
        }

        public function updateRecords( $record_id, $data ) {
            $this->db->where('id', $record_id)
                    ->update('student', $data);
        }

        public function deleteRecord( $record_id ) {
            return $this->db->delete('student', array('id' => $record_id));  // Produces: // DELETE FROM mytable  // WHERE id = $id
        }
    }

?>